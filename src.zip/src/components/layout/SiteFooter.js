import { Box, Button, Container, Flex, Grid, Heading, Image, Text } from "@chakra-ui/react";
import design from "../../design/system";

export default function SiteFooter() {
  return (
    <Box as="footer" bg={design.colors.ink} color="#FFFFFF">
      <Container maxW={design.sizes.container} px={design.spacing.pageX}>
        <Grid
          py={{ base: 12, md: 16 }}
          borderTop="1px solid rgba(255,255,255,.1)"
          templateColumns={{ base: "1fr", md: "1.2fr .8fr .8fr" }}
          gap={{ base: 12, md: 10 }}
        >
          <Box>
            <Box w="34px" h="2px" mb={6} bg={design.colors.champagne} />
            <Text
              fontSize="20px"
              fontWeight="650"
              letterSpacing="-0.05em"
              color="#FFFFFF"
            >
              ODA-AZ-ADÓ
            </Text>
            <Text
              mt={5}
              maxW="330px"
              fontSize="12px"
              lineHeight="1.7"
              color="rgba(255,255,255,.42)"
            >
              Könyvelés és szakmai támogatás vállalkozásoknak.
            </Text>
          </Box>

          <Box>
            <Text mb={5} fontSize="10px" color="rgba(255,255,255,.3)">
              Oldalak
            </Text>

            {[
              ["Könyvelés", "/konyveles"],
              ["Adótanácsadás", "/szolgaltatasok/adotanacsadas"],
              ["Bérszámfejtés", "/szolgaltatasok/berelszamolas"],
              ["Rólunk", "/rolunk"],
              ["Könyvelőváltás", "/konyvelovaltas"],
              ["Kapcsolat", "/kapcsolat"],
            ].map(([label, href]) => (
              <Text
                key={label}
                as="a"
                href={href}
                display="block"
                mb={3}
                fontSize="12px"
                color="rgba(255,255,255,.64)"
                transition={design.transition}
                _hover={{ color: design.colors.champagne }}
              >
                {label}
              </Text>
            ))}
          </Box>

          <Box>
            <Text mb={5} fontSize="10px" color="rgba(255,255,255,.3)">
              ODA-AZ-ADÓ Kft.
            </Text>
            <Text
              fontSize="12px"
              lineHeight="1.8"
              color="rgba(255,255,255,.58)"
            >
              4026 Debrecen
              <br />
              Csokonai utca 4. 3/7.
            </Text>
          </Box>
        </Grid>

        <Flex
          py={6}
          borderTop="1px solid rgba(255,255,255,.08)"
          direction={{ base: "column", sm: "row" }}
          justify="space-between"
          gap={4}
        >
          <Text fontSize="9px" color="rgba(255,255,255,.26)">
            © 2026 ODA-AZ-ADÓ Kft.
          </Text>

          <Flex gap={6}>
            <Text
              as="a"
              href="/adatkezeles"
              fontSize="9px"
              color="rgba(255,255,255,.34)"
              _hover={{ color: design.colors.champagne }}
            >
              Adatkezelés
            </Text>
            <Text
              as="a"
              href="/kapcsolat"
              fontSize="9px"
              color="rgba(255,255,255,.34)"
              _hover={{ color: design.colors.champagne }}
            >
              Kapcsolat
            </Text>
          </Flex>
        </Flex>
      </Container>
    </Box>
  );
}
