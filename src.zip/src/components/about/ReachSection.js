import { Box, Grid, Heading, Text } from "@chakra-ui/react";
import PageContainer from "../ui/PageContainer";
import Section from "../ui/Section";
import design from "../../design/system";

const MAP_URL =
  "https://upload.wikimedia.org/wikipedia/commons/a/a0/Debrecen_t%C3%A9rk%C3%A9pe.png";
export default function ReachSection() {
  return (
    <Section
      py={{ base: 20, md: 28, lg: 34 }}
      position="relative"
      overflow="hidden"
    >
      {/* Mobil háttérkép */}
      <Box
        display={{ base: "block", lg: "none" }}
        position="absolute"
        inset="0"
        bgImage={"url('https://ih1.redbubble.net/image.25371185.9195/flat%2C750x1000%2C075%2Ct.jpg')"}
        bgSize="cover"
        bgPosition="center"
        bgRepeat="no-repeat"
        filter="grayscale(100%)"
      />

      <Box
        display={{ base: "block", lg: "none" }}
        position="absolute"
        inset="0"
        bg="rgba(248, 246, 241, 0.85)"
      />

      <PageContainer position="relative" zIndex="1">
        <Grid
          templateColumns={{ base: "1fr", lg: "1.08fr .92fr" }}
          gap={{ base: 14, lg: 18, xl: 24 }}
          alignItems="stretch"
        >
          <Box>
            <Text
              fontSize="10px"
              fontWeight="600"
              letterSpacing=".16em"
              textTransform="uppercase"
              color={design.colors.champagne}
            >
              Helyben és online
            </Text>

            <Heading
              as="h2"
              mt={6}
              maxW="790px"
              fontFamily={design.fonts.sans}
              fontSize={{ base: "41px", md: "57px", lg: "67px" }}
              fontWeight="500"
              lineHeight="1"
              letterSpacing="-.058em"
              color={design.colors.ink}
            >
              Debrecenből indultunk. Ma már nem a távolság határozza meg az
              együttműködést.
            </Heading>

            <Grid
              mt={{ base: 11, md: 14 }}
              templateColumns={{ base: "1fr", md: "1fr 1fr" }}
              gap={8}
            >
              <Box
                pt={6}
                borderTop="1px solid"
                borderColor={design.colors.border}
              >
                <Text
                  fontSize="12px"
                  fontWeight="600"
                  color={design.colors.ink}
                >
                  Debrecen
                </Text>

                <Text
                  mt={3}
                  fontSize="13px"
                  lineHeight="1.72"
                  color={design.colors.muted}
                >
                  A helyi jelenlét és a személyes együttműködés továbbra is
                  fontos része az irodának.
                </Text>
              </Box>

              <Box
                pt={6}
                borderTop="1px solid"
                borderColor={design.colors.border}
              >
                <Text
                  fontSize="12px"
                  fontWeight="600"
                  color={design.colors.ink}
                >
                  Budapest és országosan
                </Text>

                <Text
                  mt={3}
                  fontSize="13px"
                  lineHeight="1.72"
                  color={design.colors.muted}
                >
                  Digitális dokumentumkezeléssel és online kapcsolattartással
                  ugyanaz a szakmai háttér távolról is elérhető.
                </Text>
              </Box>
            </Grid>
          </Box>

          {/* Desktop térkép */}
          <Box
            display={{ base: "none", lg: "block" }}
            minH="100%"
            position="relative"
            overflow="hidden"
            bg={design.colors.offWhite}
          >
            <Box
              as="img"
              src={MAP_URL}
              alt="Debrecen térképe"
              position="absolute"
              inset="0"
              w="100%"
              h="100%"
              objectFit="cover"
              filter="grayscale(100%) contrast(.9)"
            />

            {/* enyhe brand overlay */}
            <Box
              position="absolute"
              inset="0"
              bg="rgba(16, 38, 51, 0.07)"
            />

            {/* Debrecen label */}
            <Box
              position="absolute"
              left="9%"
              bottom="9%"
              bg="rgba(255,255,255,.92)"
              px={5}
              py={4}
              backdropFilter="blur(10px)"
            >
              <Text
                fontSize="9px"
                fontWeight="600"
                letterSpacing=".14em"
                textTransform="uppercase"
                color={design.colors.champagne}
              >
                Központ
              </Text>

              <Text
                mt={1}
                fontSize="27px"
                fontWeight="500"
                letterSpacing="-.04em"
                color={design.colors.ink}
              >
                Debrecen
              </Text>
            </Box>
          </Box>
        </Grid>
      </PageContainer>
    </Section>
  );
}