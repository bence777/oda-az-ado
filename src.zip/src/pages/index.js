import Head from "next/head";
import PageShell from "@/components/layout/PageShell";
import HomeHero from "@/components/home/HomeHero";
import TrustSection from "@/components/home/TrustSection";
import ServicesSection from "@/components/home/ServicesSection";
import ProcessSection from "@/components/home/ProcessSection";
import ManagementSection from "@/components/home/ManagementSection";
import AccountantSwitchSection from "@/components/home/AccountantSwitchSection";
import AboutSection from "@/components/home/AboutSection";
import LocationsSection from "@/components/home/LocationsSection";
import FinalCta from "@/components/home/FinalCta";

export default function Home() {
  return (
    <>
      <Head>
        <title>Oda-Az-Adó | Könyvelés Debrecenben és online</title>
        <meta name="description" content="Könyvelés, adótanácsadás, bérszámfejtés és vezetői információ vállalkozásoknak Debrecenben, Budapesten és online országosan." />
      </Head>
      <PageShell>
        <HomeHero />
        <TrustSection />
        <ServicesSection />
        <ProcessSection />
        <ManagementSection />
        <AccountantSwitchSection />
        <AboutSection />
        <LocationsSection />
        <FinalCta />
      </PageShell>
    </>
  );
}
