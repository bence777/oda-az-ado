import Head from "next/head";
import PageShell from "@/components/layout/PageShell";
import AboutHero from "@/components/about/AboutHero";
import ExperienceSection from "@/components/about/ExperienceSection";
import PositioningSection from "@/components/about/PositioningSection";
import PrinciplesSection from "@/components/about/PrinciplesSection";
import ReachSection from "@/components/about/ReachSection";
import AboutCta from "@/components/about/AboutCta";

export default function AboutPage() {
  return (
    <>
      <Head>
        <title>Rólunk | Oda-Az-Adó</title>
        <meta
          name="description"
          content="Több mint egy évtized szakmai tapasztalat, rendezett folyamatok és személyesebb együttműködés. Ismerje meg az Oda-Az-Adó szemléletét."
        />
      </Head>

      <PageShell>
        <AboutHero />
        <ExperienceSection />
        <PositioningSection />
        <PrinciplesSection />
        <ReachSection />
        <AboutCta />
      </PageShell>
    </>
  );
}
